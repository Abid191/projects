module.exports = {
  //...
  plugins: [require("daisyui"), require("flowbite/plugin")],
};
